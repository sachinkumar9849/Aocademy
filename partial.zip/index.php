<?php include 'partial/header.php'; ?>

<main id="content" class="site-main">
    <header class="sliderWrap">
        <div class="owl-carousel owl-theme">
            <div class="item">
                <img src="https://sportszone.dexignzone.com/xhtml/images/background/bg1.jpg">
                <div class="cover">
                    <div class="container">
                        <div class="header-content">
                            <div class="line"></div>
                            <!-- <h2>MATCH OVERVIEW
                            </h2> -->
                            <div class="py-3">
                                <h1>Welcome to the World <br> of Sports</h1>
                            </div>
                            <h4>
                                <div id="btnSlider" class="btnCustom"> <a href="tel:1300 468 463"><span class="mr-1"></span></span> Learn More</a> </div>
                            </h4>
                            <!-- <h4>More productivity, less downtime, <br> and no hassles. IT should be THAT simple.</h4> -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="item">
                <img src="https://assets.fiba.basketball/image/upload/w_1600,h_658,c_fill,g_auto/q_auto/f_auto/v1723673416/fbcx4s5ih9mxhzyowzpl" alt="images not found">
                <div class="cover">
                    <div class="container">
                        <div class="header-content">
                            <div class="line"></div>
                            <!-- <h2>MATCH OVERVIEW
                            </h2> -->
                            <div class="py-3">
                                <h1>Welcome to the World <br> of Sports</h1>
                            </div>
                            <h4>
                                <div id="btnSlider" class="btnCustom"> <a href="tel:1300 468 463"><span class="mr-1"></span></span> Learn More</a> </div>
                            </h4>
                            <!-- <h4>More productivity, less downtime, <br> and no hassles. IT should be THAT simple.</h4> -->
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </header>
    <!-- <section class="partnerHome padding">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="partnerSlider slick-slider">
                        <div class="partnerItem">
                            <a href="" class="partnerImg">
                                <img class="img-fluid" src="https://demo2.themelexus.com/neotech/wp-content/uploads/2024/10/brand01.svg" alt="">
                            </a>
                        </div>
                        <div class="partnerItem">
                            <a href="" class="partnerImg">
                                <img class="img-fluid" src="https://demo2.themelexus.com/neotech/wp-content/uploads/2024/10/brand05.svg" alt="">
                            </a>
                        </div>
                        <div class="partnerItem">
                            <a href="" class="partnerImg">
                                <img class="img-fluid" src="https://demo2.themelexus.com/neotech/wp-content/uploads/2024/10/brand04.svg" alt="">
                            </a>
                        </div>
                        <div class="partnerItem">
                            <a href="" class="partnerImg">
                                <img class="img-fluid" src="https://demo2.themelexus.com/neotech/wp-content/uploads/2024/10/brand03.svg" alt="">
                            </a>
                        </div>
                        <div class="partnerItem">
                            <a href="" class="partnerImg">
                                <img class="img-fluid" src="https://demo2.themelexus.com/neotech/wp-content/uploads/2024/10/brand01.svg" alt="">
                            </a>
                        </div>
                        <div class="partnerItem">
                            <a href="" class="partnerImg">
                                <img class="img-fluid" src="https://demo2.themelexus.com/neotech/wp-content/uploads/2024/10/brand01.svg" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

    <div class="hp-hero__cta" style="min-height: 145px;">
        <div class="hp-hero__cta-spacer"></div>
        <nav class="hp-hero__cta-nav" aria-label="Impact menu">
            <ul class="hp-hero__cta-items">
                <li class="hp-hero__cta-item wow fadeInUp" data-wow-delay="0s" style="visibility: visible; animation-delay: 0s;">
                    <a class="hp-hero__cta-item-anchor" href="">
                        <div class="hp-hero__cta-item-container" data-expand="-42px">
                            <picture>
                                <source srcset="https://english.pardafas.com/wp-content/uploads/2024/11/npl-6.jpg" type="image/webp">
                                <img loading="lazy" class="hp-hero__cta-item-background" src="https://english.pardafas.com/wp-content/uploads/2024/11/npl-6.jpg" alt="">
                            </picture>
                            <div class="hp-hero__cta-item-mask"></div>

                            <div class="hp-hero__cta-item-title">Cricket</div>
                            <div class="hp-hero__cta-item-caption">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus aperiam esse in</div>
                        </div>
                    </a>
                </li>
                <li class="hp-hero__cta-item wow fadeInUp" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s;">
                    <a class="hp-hero__cta-item-anchor" href="">
                        <div class="hp-hero__cta-item-container" data-expand="-42px">
                            <picture>
                                <source srcset="https://guardian.ng/wp-content/uploads/2024/05/FblEurC1PsgDortmund.jpg" type="image/webp">
                                <img loading="lazy" class="hp-hero__cta-item-background" src="https://guardian.ng/wp-content/uploads/2024/05/FblEurC1PsgDortmund.jpg" alt="">
                            </picture>
                            <div class="hp-hero__cta-item-mask"></div>

                            <div class="hp-hero__cta-item-title">FootBall</div>
                            <div class="hp-hero__cta-item-caption"></div>
                        </div>
                    </a>
                </li>
                <li class="hp-hero__cta-item wow fadeInUp" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s;">
                    <a class="hp-hero__cta-item-anchor" href="">
                        <div class="hp-hero__cta-item-container" data-expand="-42px">
                            <picture>
                                <source srcset="https://assets01.sdd1.ch/assets/lbwp-cdn/mobilesport/files/1686122888/basket_erscheinungsformen-1440x782.jpg" type="image/webp">
                                <img loading="lazy" class="hp-hero__cta-item-background" src="https://assets01.sdd1.ch/assets/lbwp-cdn/mobilesport/files/1686122888/basket_erscheinungsformen-1440x782.jpg" alt="">
                            </picture>
                            <div class="hp-hero__cta-item-mask"></div>

                            <div class="hp-hero__cta-item-title">BasketBall</div>
                            <div class="hp-hero__cta-item-caption"></div>
                        </div>
                    </a>
                </li>
                <li class="hp-hero__cta-item wow fadeInUp" data-wow-delay="0s" style="visibility: visible; animation-delay: 0s;">
                    <a class="hp-hero__cta-item-anchor" href="">
                        <div class="hp-hero__cta-item-container" data-expand="-42px">
                            <picture>
                                <source srcset="https://english.pardafas.com/wp-content/uploads/2024/11/npl-6.jpg" type="image/webp">
                                <img loading="lazy" class="hp-hero__cta-item-background" src="https://english.pardafas.com/wp-content/uploads/2024/11/npl-6.jpg" alt="">
                            </picture>
                            <div class="hp-hero__cta-item-mask"></div>

                            <div class="hp-hero__cta-item-title">Cricket</div>
                            <div class="hp-hero__cta-item-caption">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus aperiam esse in</div>
                        </div>
                    </a>
                </li>
               
            </ul>
        </nav>
        <div class="hp-hero__cta-spacer"></div>
    </div>

    <section class="services padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mx-auto text-center">
                    <div class="sectionTitle">
                        <p class="wow fadeInUp">Trading Posts
                        </p>
                        <h1 class="wow fadeInUp">See who's trending</h1>
                    </div>
                </div>
            </div>
            <!-- <div class="servicesSlider slick-slider">
                <div class="servicesSliderItem">
                    
                </div>
               
            </div> -->
            <div class="trendingSlider slick-slider">
                <div class="blogItemSlider">
                    <div class="blogWrap">
                        <a href="">
                            <div class="blogImg">
                                <img class="img-fluid" src="https://sport.kicker.axiomthemes.com/wp-content/uploads/2021/01/post9-copyright-642x428.jpg" alt="">
                            </div>
                        </a>
                        <div class="blogContent">
                            <span><i class="fa fa-calendar" aria-hidden="true"></i>
                                October 28, 2024</span>
                            <h3>Professional Golf Tips: Playing at Luxury ..</h3>
                            <div class="textBtn">
                                <a href="">Learn MORE <span><i class="fa fa-arrow-right"></i></span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="blogItemSlider">
                    <div class="blogWrap">
                        <a href="">
                            <div class="blogImg">
                                <img class="img-fluid" src="https://sport.kicker.axiomthemes.com/wp-content/uploads/2021/01/post11-copyright-642x428.jpg" alt="">
                            </div>
                        </a>
                        <div class="blogContent">
                            <span><i class="fa fa-calendar" aria-hidden="true"></i>
                                10 October 2020</span>
                            <h3>Equipment that Creates Your Game
                            </h3>
                            <div class="textBtn">
                                <a href="">Learn MORE <span><i class="fa fa-arrow-right"></i></span></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="blogItemSlider">
                    <div class="blogWrap">
                        <a href="">
                            <div class="blogImg">
                                <img class="img-fluid" src="https://sport.kicker.axiomthemes.com/wp-content/uploads/2021/01/post14-copyright-642x428.jpg" alt="">
                            </div>
                        </a>
                        <div class="blogContent">
                            <span><i class="fa fa-calendar" aria-hidden="true"></i>
                                08 October 2020</span>
                            <h3>Quality Time at a Motorsport Park..</h3>
                            <div class="textBtn">
                                <a href="">Learn MORE <span><i class="fa fa-arrow-right"></i></span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="blogItemSlider">
                    <div class="blogWrap">
                        <a href="">
                            <div class="blogImg">
                                <img class="img-fluid" src="https://sport.kicker.axiomthemes.com/wp-content/uploads/2021/01/post17-copyright-642x420.jpg" alt="">
                            </div>
                        </a>
                        <div class="blogContent">
                            <span><i class="fa fa-calendar" aria-hidden="true"></i>
                                07 October 2020
                            </span>
                            <h3>Quality Time at a Motorsport Park...</h3>
                            <div class="textBtn">
                                <a href="">Learn MORE <span><i class="fa fa-arrow-right"></i></span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="blogItemSlider">
                    <div class="blogWrap">
                        <a href="">
                            <div class="blogImg">
                                <img class="img-fluid" src="https://sport.kicker.axiomthemes.com/wp-content/uploads/2021/01/post11-copyright-642x428.jpg" alt="">
                            </div>
                        </a>
                        <div class="blogContent">
                            <span><i class="fa fa-calendar" aria-hidden="true"></i>
                                10 October 2020</span>
                            <h3>Equipment that Creates Your Game
                            </h3>
                            <div class="textBtn">
                                <a href="">Learn MORE <span><i class="fa fa-arrow-right"></i></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <div class="row">
                <div class="col-12">
                    <div class="servicesButtom wow fadeInUp">
                        <span> <span class="pr-2 mb-md-0 mb-2">Lorem ipsum dolor sit amet, consectetur adipisicing elit. </span>
                            <div class="btnCustom">See All <span class="ml-1"><i class="fa fa-arrow-right"></i></span> </div>
                            <!-- <a href="">See All Services <i class="fa fa-arrow-right"></i></a> </span> -->
                    </div>
                </div>
            </div>

        </div>

    </section>




    <section class="about padding">
        <div class="container">
            <div class="row">

                <div class="col-lg-6">
                    <div class="sectionTitle">
                        <p class="wow fadeInUp" style="
                            margin-left: 18px;
                        ">About Us</p>
                        <h1 class="wow fadeInUp">About The Sports</h1>
                    </div>
                    <p class="wow fadeInUp">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem, necessitatibus commodi sunt delectus odio debitis rerum velit perspiciatis quis aliquid illum impedit ut aut quasi iste provident? Esse, tempora eligendi.

                    </p>
                    <p class="wow fadeInUp">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, tempora unde quibusdam quisquam et sed veritatis autem pariatur nobis error nostrum ipsam laboriosam, dolor sequi dolore quidem voluptates. Similique, omnis!</p>
                    <div class="mt-4 wow fadeInUp">
                        <a href="who-we-are.php">
                            <div class="btnCustom">Learn More <span class="ml-1"><i class="fa fa-arrow-right"></i></span> </div>
                        </a>

                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about_imgWrap">
                        <div class="imgOne">
                            <img src="https://demo.ovatheme.com/spoclub/wp-content/uploads/2022/11/home-1-our-club-b.jpg" class="wow fadeInUp img-fluid" alt="">
                        </div>
                        <div class="imgtwo ">
                            <img src="https://sport.kicker.axiomthemes.com/wp-content/uploads/2021/01/post17-copyright-642x420.jpg" class="img-fluid wow fadeInUp" alt="">
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>


    <!-- VIDEO START  -->
    <section class="videoSection padding pb-0 position-relative" style="
    background-image: url(https://st3.depositphotos.com/1000423/16437/i/450/depositphotos_164375318-stock-photo-soccer-best-moments-mixed-media.jpg);
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    background-attachment: fixed;
">
        <div class="container-fluid px-0">
            <div class="row">
                <div class="col-lg-6 mx-auto text-center">
                    <div class="sectionTitle ">
                        <p class="text-white wow fadeInUp">Videos</p>
                        <h1 class="text-white wow fadeInUp">Latest Videos</h1>
                    </div>
                </div>
            </div>
            <div class="vid-slider">
                <div class="sliderVideo vid-wrapper">

                    <div class="vid item">
                        <iframe width="100%" height="300" src="https://www.youtube.com/embed/aTTOQtSOX3I" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        <h2 class="vid-head">Equipment that Creates Your Game
                        </h2>
                    </div>
                    <div class="vid item">
                        <iframe width="100%" height="300" src="https://www.youtube.com/embed/cRpVkWjCRtc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                        <h2 class="vid-head">Professional Golf Tips: Playing at Luxury ..
                        </h2>
                    </div>
                    <div class="vid item">
                        <iframe width="100%" height="300" src="https://www.youtube.com/embed/aTTOQtSOX3I" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        <h2 class="vid-head">Equipment that Creates Your Game
                        </h2>
                    </div>
                    <div class="vid item">
                        <iframe width="100%" height="300" src="https://www.youtube.com/embed/cRpVkWjCRtc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                        <h2 class="vid-head">Professional Golf Tips: Playing at Luxury ..
                        </h2>
                    </div>
                    <div class="vid item">
                        <iframe width="100%" height="300" src="https://www.youtube.com/embed/wZPnZzKJuFI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                        <h2 class="vid-head">Professional Golf Tips: Playing at Luxury ..
                        </h2>
                    </div>



                </div>
            </div>
        </div>
        <div class="video-popup">
            <div class="iframe-wrapper"><iframe width="700" height="500" src="" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                <span class="close-video">
                    <i class="fas fa-times"></i>

                </span>
            </div>
        </div>


    </section>
    <!-- VIDEO END  -->


    <section id="news_section" class="padding bg_gray news_section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mx-auto text-center">
                    <div class="sectionTitle">
                        <p class="wow fadeInUp">Stories</p>
                        <h1 class="wow fadeInUp">Top stories
                        </h1>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 col-md-12 wow fadeInUp">
                    <div class="news_men position-relative mb-lg-0 mb-4 ">
                        <div class="news_img">
                            <img class="img-fluid" src="https://sportszone.dexignzone.com/xhtml/images/blog/latest-blog3/pic1.jpg" alt="img">
                        </div>

                        <div class="news_des">
                            <p class="text-white font-bold"><i class="fa fa-clock-o" aria-hidden="true"></i>September 16, 2024</p>
                            <h5><a href="" class="text-white">Paris 2024 had it all: Sporting drama, revered venues, singalongs... and Snoop Dogg</a></h5>

                        </div>

                    </div>
                </div>
                <div class="col-lg-6 col-md-12 wow fadeInUp">
                    <div class="new_list_items">

                        <div class="news-listing-panel d-flex">
                            <div class="news_list_img">
                                <img src="https://sportszone.dexignzone.com/xhtml/images/blog/latest-blog3/pic2.jpg" class="img-fluid" alt="img">
                            </div>
                            <div class="news_list_des p-4">
                                <div class="time-location-panel">
                                    <p class="text-white"><i class="fa fa-clock-o" aria-hidden="true"></i>September 24, 2024</p>
                                </div>
                                <h5><a href="">

                                        Three-Day Training for Child Helpline 1098 on Child Protection with… </a></h5>

                                <div class="twoBtnHeader mt-3" id="topHeaderAnimatedbtn">

                                    <button class="btnRemote border-animation">Learn more</button>



                                </div>
                            </div>

                        </div>


                        <div class="news-listing-panel d-flex">
                            <div class="news_list_img">
                                <img src="https://sportszone.dexignzone.com/xhtml/images/blog/latest-blog3/pic3.jpg" class="img-fluid" alt="img">
                            </div>
                            <div class="news_list_des p-4">
                                <div class="time-location-panel">
                                    <p class="text-white"><i class="fa fa-clock-o" aria-hidden="true"></i>September 24, 2024</p>
                                </div>
                                <h5><a href="">

                                        Three-Day Training for Child Helpline 1098 on Child Protection with… </a></h5>

                                <div class="twoBtnHeader mt-3" id="topHeaderAnimatedbtn">

                                    <button class="btnRemote border-animation">Learn more</button>



                                </div>
                            </div>

                        </div>



                    </div>
                </div>
            </div>

        </div>
    </section>
    <img src="https://tpc.googlesyndication.com/simgad/4211264056666667658" class="wow fadeInUp img-fluid w-100" alt="">




    <!-- Gallery start  -->
    <section class="padding position-relative" id="gallerySection" style="
    background-image: url(https://sportszone.dexignzone.com/xhtml/images/background/bg1.jpg);
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
">
        <div class="container">

            <div class="section-padding gallery-section" id="gallery">
                <div class="container">
                    <!-- Section Title Start -->
                    <div class="row">
                        <div class="col-lg-6 mx-auto text-center">
                            <div class="sectionTitle ">
                                <p class="text-white wow fadeInUp">Videos</p>
                                <h1 class="text-white wow fadeInUp">Latest Videos</h1>
                            </div>
                        </div>
                    </div>
                    <!-- Section Title End -->

                    <div id="btncontainer" class="filter">
                        <a class="btn btn-active" href="#all">ALL</a>
                        <a class="btn" href="#cricket">Cricket</a>
                        <a class="btn" href="#football">FootBall</a>
                        <a class="btn" href="#jumping">Jumping</a>
                    </div>

                    <!-- Gallery Section Start -->

                    <div class="gallery sets">
                        <a class="all cricket"><img class="imgCustom" src="https://sportszone.dexignzone.com/xhtml/images/gallery/pic1.jpg" /></a>

                        <a class="all cricket"><img class="imgCustom" src="https://sportszone.dexignzone.com/xhtml/images/gallery/pic2.jpg" /></a>

                        <a class="all cricket"><img class="imgCustom" src="https://sportszone.dexignzone.com/xhtml/images/gallery/pic3.jpg" /></a>

                        <a class="all cricket"><img class="imgCustom" src="https://sportszone.dexignzone.com/xhtml/images/gallery/pic4.jpg" /></a>

                        <a class="all football"><img class="imgCustom" src="https://fifpro.org/media/h0npqx2a/pwm-release_2023.jpg?rxy=0.61180719339622647,0.11599601450477044&width=1600&height=1024&rnd=133307322431130000" /></a>

                        <a class="all football"><img class="imgCustom" src="https://sportszone.dexignzone.com/xhtml/images/gallery/pic8.jpg" /></a>

                        <a class="all jumping"><img class="imgCustom" src="https://sportszone.dexignzone.com/xhtml/images/gallery/pic7.jpg" /></a>
                        <a class="all jumping"><img class="imgCustom" src="https://sportszone.dexignzone.com/xhtml/images/gallery/pic5.jpg" /></a>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Gallery end  -->

    <section class="teamSection padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mx-auto text-center">
                    <div class="sectionTitle">
                        <p class="wow fadeInUp">Team</p>
                        <h1 class="wow fadeInUp">Qualified Staff
                        </h1>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-sm-6 wow fadeInUp">
                    <div id="teamMember" class="dez-box m-b30 dez-img-effect vertical-pan dez-staff">
                        <div class="dez-media vertical-pan dez-img-effect">
                            <a href="javascript:;">
                                <img src="https://sportszone.dexignzone.com/xhtml/images/our-team/pic2.jpg" alt="" width="358" height="460">
                            </a>
                        </div>
                        <div class="p-a15 bg-primary text-white dez-team">
                            <h4 class="dez-title text-capitalize mb-2">andrea</h4>
                            <div class="dez-separator-outer ">
                                <div class="dez-separator bg-white style-liner"></div>
                            </div>
                            <span class="dez-member-position" style="
                                display: flex;
                                justify-content: center;
                            ">Coatch</span>
                            <div class="m-t10">
                                <ul class="dez-social-icon dez-social-icon-lg ml-0 pl-0">
                                    <li><i class="fab fa-facebook"></i></li>
                                    <li><i class="fab fa-instagram"></i></li>
                                    <li><i class="fab fa-twitter"></i></li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp">
                    <div id="teamMember" class="dez-box m-b30 dez-img-effect vertical-pan dez-staff">
                        <div class="dez-media vertical-pan dez-img-effect">
                            <a href="javascript:;">
                                <img src="https://sportszone.dexignzone.com/xhtml/images/our-team/pic1.jpg" alt="" width="358" height="460">
                            </a>
                        </div>
                        <div class="p-a15 bg-primary text-white dez-team">
                            <h4 class="dez-title text-capitalize mb-2">andrea</h4>
                            <div class="dez-separator-outer ">
                                <div class="dez-separator bg-white style-liner"></div>
                            </div>
                            <span class="dez-member-position" style="
                                display: flex;
                                justify-content: center;
                            ">Coatch</span>
                            <div class="m-t10">
                                <ul class="dez-social-icon dez-social-icon-lg ml-0 pl-0">
                                    <li><i class="fab fa-facebook"></i></li>
                                    <li><i class="fab fa-instagram"></i></li>
                                    <li><i class="fab fa-twitter"></i></li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp">
                    <div id="teamMember" class="dez-box m-b30 dez-img-effect vertical-pan dez-staff">
                        <div class="dez-media vertical-pan dez-img-effect">
                            <a href="javascript:;">
                                <img src="https://sportszone.dexignzone.com/xhtml/images/our-team/pic3.jpg" alt="" width="358" height="460">
                            </a>
                        </div>
                        <div class="p-a15 bg-primary text-white dez-team">
                            <h4 class="dez-title text-capitalize mb-2">andrea</h4>
                            <div class="dez-separator-outer ">
                                <div class="dez-separator bg-white style-liner"></div>
                            </div>
                            <span class="dez-member-position" style="
                                display: flex;
                                justify-content: center;
                            ">Coatch</span>
                            <div class="m-t10">
                                <ul class="dez-social-icon dez-social-icon-lg ml-0 pl-0">
                                    <li><i class="fab fa-facebook"></i></li>
                                    <li><i class="fab fa-instagram"></i></li>
                                    <li><i class="fab fa-twitter"></i></li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 wow fadeInUp">
                    <div id="teamMember" class="dez-box m-b30 dez-img-effect vertical-pan dez-staff">
                        <div class="dez-media vertical-pan dez-img-effect">
                            <a href="javascript:;">
                                <img src="https://sportszone.dexignzone.com/xhtml/images/our-team/pic4.jpg" alt="" width="358" height="460">
                            </a>
                        </div>
                        <div class="p-a15 bg-primary text-white dez-team">
                            <h4 class="dez-title text-capitalize mb-2">andrea</h4>
                            <div class="dez-separator-outer ">
                                <div class="dez-separator bg-white style-liner"></div>
                            </div>
                            <span class="dez-member-position" style="
                                display: flex;
                                justify-content: center;
                            ">Coatch</span>
                            <div class="m-t10">
                                <ul class="dez-social-icon dez-social-icon-lg ml-0 pl-0">
                                    <li><i class="fab fa-facebook"></i></li>
                                    <li><i class="fab fa-instagram"></i></li>
                                    <li><i class="fab fa-twitter"></i></li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <section class="testimonial padding position-relative pb-0" style="
    background-image: url(https://sportszone.dexignzone.com/xhtml/images/mamber.jpg);
    background-position: center;
    background-size: cover;
">

        <div class="container">
            <div class="row">
                <div class="col-lg-6 mx-auto text-center">
                    <div class="sectionTitle ">
                        <p class="text-white wow fadeInUp">WHAT CLIENTS SAY</p>
                        <h1 class="text-white wow fadeInUp">Testimonials</h1>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="slickSliderWrap">
                        <div class="testimonial-slider slick-slider">
                            <div class="slickItem">
                                <div class="slickStar">
                                    <ul class="pl-0">
                                        <li>
                                            <i class="fas fa-star"></i>

                                        </li>
                                        <li>
                                            <i class="fas fa-star"></i>

                                        </li>
                                        <li>
                                            <i class="fas fa-star"></i>

                                        </li>
                                        <li>
                                            <i class="fas fa-star"></i>

                                        </li>
                                        <li>
                                            <i class="fas fa-star"></i>


                                        </li>
                                    </ul>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis iste culpa et accusamus debitis. Quas minus consectetur provident voluptas quam sunt quae inventore iure at libero beatae, architecto, natus commodi!</p>
                                </div>
                                <div class="testUser">
                                    <div class="testImg">
                                        <img src="https://demo2.themelexus.com/neotech/wp-content/uploads/2024/10/avatar-2.png" class="img-fluid" alt="">
                                    </div>
                                    <div class="testContent">
                                        <h3>Alex Rony</h3>
                                        <small>Project Manager</small>
                                    </div>
                                </div>


                            </div>
                            <div class="slickItem">
                                <div class="slickStar">
                                    <ul class="pl-0">
                                        <li>
                                            <i class="fas fa-star"></i>

                                        </li>
                                        <li>
                                            <i class="fas fa-star"></i>

                                        </li>
                                        <li>
                                            <i class="fas fa-star"></i>

                                        </li>
                                        <li>
                                            <i class="fas fa-star"></i>

                                        </li>
                                        <li>
                                            <i class="fas fa-star-half-alt"></i>


                                        </li>
                                    </ul>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis iste culpa et accusamus debitis. Quas minus consectetur provident voluptas quam sunt quae inventore iure at libero beatae, architecto, natus commodi!</p>
                                </div>
                                <div class="testUser">
                                    <div class="testImg">
                                        <img src="https://demo2.themelexus.com/neotech/wp-content/uploads/2024/10/avatar-2.png" class="img-fluid" alt="">
                                    </div>
                                    <div class="testContent">
                                        <h3>Alex Rony</h3>
                                        <small>Project Manager</small>
                                    </div>
                                </div>


                            </div>
                            <div class="slickItem">
                                <div class="slickStar">
                                    <ul class="pl-0">
                                        <li>
                                            <i class="fas fa-star"></i>

                                        </li>
                                        <li>
                                            <i class="fas fa-star"></i>

                                        </li>
                                        <li>
                                            <i class="fas fa-star"></i>

                                        </li>
                                        <li>
                                            <i class="fas fa-star"></i>

                                        </li>
                                        <li>
                                            <i class="fas fa-star-half-alt"></i>


                                        </li>
                                    </ul>
                                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis iste culpa et accusamus debitis. Quas minus consectetur provident voluptas quam sunt quae inventore iure at libero beatae, architecto, natus commodi!</p>
                                </div>
                                <div class="testUser">
                                    <div class="testImg">
                                        <img src="https://demo2.themelexus.com/neotech/wp-content/uploads/2024/10/avatar-2.png" class="img-fluid" alt="">
                                    </div>
                                    <div class="testContent">
                                        <h3>Alex Rony</h3>
                                        <small>Project Manager</small>
                                    </div>
                                </div>


                            </div>


                        </div>
                    </div>

                </div>
            </div>
        </div>

    </section>

    <div class="container">
        <div class="borderButtom"></div>

        <section class="blogSec padding">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 mx-auto text-center">
                        <div class="sectionTitle">
                            <p class="wow fadeInUp">From our blog</p>
                            <h1 class="wow fadeInUp">The Latest Articles
                            </h1>
                        </div>
                    </div>
                </div>
                <div class="blogSlider slick-slider">
                    <div class="blogItemSlider">
                        <div class="blogWrap">
                            <a href="">
                                <div class="blogImg">
                                    <img class="img-fluid" src="https://backtheme.com/neoton/wp-content/uploads/2022/08/28-600x600.jpg" alt="">
                                </div>
                            </a>
                            <div class="blogContent">
                                <span><i class="fa fa-calendar" aria-hidden="true"></i>
                                    October 28, 2024</span>
                                <h3>Tempore imperdiet rhoncus ipsam lobortis kolat.</h3>
                                <div class="textBtn">
                                    <a href="">Learn MORE <span><i class="fa fa-arrow-right"></i></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="blogItemSlider">
                        <div class="blogWrap">
                            <a href="">
                                <div class="blogImg">
                                    <img class="img-fluid" src="https://backtheme.com/neoton/wp-content/uploads/2022/09/66-600x600.jpg" alt="">
                                </div>
                            </a>
                            <div class="blogContent">
                                <span><i class="fa fa-calendar" aria-hidden="true"></i>
                                    10 October 2020</span>
                                <h3>Tempores imperdiet rhoncus ipsam lobortis kolats.</h3>
                                <div class="textBtn">
                                    <a href="">Learn MORE <span><i class="fa fa-arrow-right"></i></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="blogItemSlider">
                        <div class="blogWrap">
                            <a href="">
                                <div class="blogImg">
                                    <img class="img-fluid" src="https://backtheme.com/neoton/wp-content/uploads/2022/08/30.jpg" alt="">
                                </div>
                            </a>
                            <div class="blogContent">
                                <span><i class="fa fa-calendar" aria-hidden="true"></i>
                                    09 October 2020</span>
                                <h3>Manchester city beat everton for the</h3>
                                <div class="textBtn">
                                    <a href="">Learn MORE <span><i class="fa fa-arrow-right"></i></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="blogItemSlider">
                        <div class="blogWrap">
                            <a href="">
                                <div class="blogImg">
                                    <img class="img-fluid" src="https://backtheme.com/neoton/wp-content/uploads/2022/09/66-600x600.jpg" alt="">
                                </div>
                            </a>
                            <div class="blogContent">
                                <span><i class="fa fa-calendar" aria-hidden="true"></i>
                                    10 October 2020</span>
                                <h3>Tempores imperdiet rhoncus ipsam lobortis kolats.</h3>
                                <div class="textBtn">
                                    <a href="">Learn MORE <span><i class="fa fa-arrow-right"></i></span></a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    </div>
</main>



<?php include 'partial/footer.php'; ?>